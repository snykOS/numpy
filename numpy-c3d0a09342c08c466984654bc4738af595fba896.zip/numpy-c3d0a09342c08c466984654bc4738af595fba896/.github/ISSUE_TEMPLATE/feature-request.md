---
name: "Feature request"
about: Check instructions for submitting your idea on the mailing list first.

---

## Feature

<!-- If you're looking to request a new feature or change in functionality, including
adding or changing the meaning of arguments to an existing function, please
post your idea on the [numpy-discussion mailing list]
(https://mail.python.org/mailman/listinfo/numpy-discussion) to explain your
reasoning in addition to opening an issue or pull request. You can also check
out our [Contributor Guide]
(https://github.com/numpy/numpy/blob/main/doc/source/dev/index.rst) if you
need more information. -->
