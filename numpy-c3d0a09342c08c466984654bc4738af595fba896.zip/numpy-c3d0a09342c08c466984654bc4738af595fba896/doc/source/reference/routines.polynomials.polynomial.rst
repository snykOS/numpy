.. versionadded:: 1.4.0

.. automodule:: numpy.polynomial.polynomial
   :no-members:
   :no-inherited-members:
   :no-special-members:
