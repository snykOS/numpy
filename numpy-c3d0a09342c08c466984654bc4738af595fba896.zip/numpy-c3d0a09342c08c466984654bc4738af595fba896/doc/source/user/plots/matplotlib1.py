import matplotlib.pyplot as plt
import numpy as np

a = np.array([2, 1, 5, 7, 4, 6, 8, 14, 10, 9, 18, 20, 22])

plt.plot(a) 
plt.show()